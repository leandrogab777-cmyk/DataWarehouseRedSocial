-- operaciones_dml.sql
-- Ejercicio 3: Operaciones DML avanzadas sobre la BD red_social_db

USE red_social_db;

------------------------------------------------------------
-- 3.1 CONSULTAS SELECT AVANZADAS
------------------------------------------------------------

-- 3.1.1 JOIN múltiple (usuarios + publicaciones + reacciones)
SELECT u.id_usuario, u.email, COUNT(r.id_reaccion) AS total_reacciones
FROM usuarios u
JOIN publicaciones p ON p.id_usuario = u.id_usuario
LEFT JOIN reacciones r ON r.id_publicacion = p.id_publicacion
GROUP BY u.id_usuario, u.email
ORDER BY total_reacciones DESC;

-- 3.1.2 Subconsulta correlacionada:
-- Usuarios con más publicaciones que el promedio de todos
SELECT u.id_usuario, u.email
FROM usuarios u
WHERE (
    SELECT COUNT(*)
    FROM publicaciones p
    WHERE p.id_usuario = u.id_usuario
) > (
    SELECT AVG(pub_por_usuario)
    FROM (
        SELECT COUNT(*) AS pub_por_usuario
        FROM publicaciones
        GROUP BY id_usuario
    ) t
);

-- 3.1.3 Funciones de agregación con GROUP BY y HAVING:
-- Usuarios con más de 10 publicaciones públicas
SELECT u.id_usuario, u.email, COUNT(p.id_publicacion) AS total_publicaciones
FROM usuarios u
JOIN publicaciones p ON p.id_usuario = u.id_usuario
WHERE p.visibilidad = 'publico'
GROUP BY u.id_usuario, u.email
HAVING COUNT(p.id_publicacion) > 10;

-- 3.1.4 Window functions (ROW_NUMBER por usuario):
SELECT
    p.id_publicacion,
    p.id_usuario,
    p.fecha_publicacion,
    ROW_NUMBER() OVER (PARTITION BY p.id_usuario ORDER BY p.fecha_publicacion DESC) AS numero_publicacion
FROM publicaciones p
WHERE p.id_usuario = 1126
ORDER BY numero_publicacion;

-- 3.1.5 UNION:
-- Unir emails de usuarios activos y baneados marcando el tipo
SELECT email, 'activo' AS tipo
FROM usuarios
WHERE estado = 'activo' AND email LIKE 'user_m1%'
UNION
SELECT email, 'baneado' AS tipo
FROM usuarios
WHERE estado = 'baneado' AND email LIKE 'user_m1%';

-- 3.1.6 CTE (Common Table Expression):
WITH publicaciones_por_usuario AS (
    SELECT id_usuario, COUNT(*) AS total_pub
    FROM publicaciones
    GROUP BY id_usuario
)
SELECT u.id_usuario, u.email, ppu.total_pub
FROM usuarios u
JOIN publicaciones_por_usuario ppu ON ppu.id_usuario = u.id_usuario
ORDER BY ppu.total_pub DESC;

-- 3.1.7 Consulta con CASE:
SELECT
    u.id_usuario,
    u.email,
    CASE
        WHEN COUNT(p.id_publicacion) = 0 THEN 'Sin publicaciones'
        WHEN COUNT(p.id_publicacion) BETWEEN 1 AND 10 THEN 'Nuevo'
        ELSE 'Activo'
    END AS categoria_usuario
FROM usuarios u
LEFT JOIN publicaciones p ON p.id_usuario = u.id_usuario
GROUP BY u.id_usuario, u.email;

-- 3.1.8 Análisis temporal con fechas:
-- Publicaciones de los últimos 7 días
SELECT *
FROM publicaciones
WHERE fecha_publicacion >= NOW() - INTERVAL 7 DAY;

-- 3.1.9 Búsqueda de texto con LIKE (simulando expresiones regulares sencillas):
SELECT *
FROM publicaciones
WHERE contenido LIKE '%MASIVO%';


------------------------------------------------------------
-- 3.2 OPERACIONES INSERT
------------------------------------------------------------

-- 3.2.1 INSERT múltiple de ejemplo
INSERT INTO usuarios (email, password_hash, estado)
VALUES ('nuevo1@example.com', 'hash_fake', 'activo'),
       ('nuevo2@example.com', 'hash_fake', 'activo');
       -- 3.2.2 INSERT con subconsulta:
INSERT INTO publicaciones (id_usuario, contenido, visibilidad)
SELECT id_usuario, 'Publicación automática para usuarios nuevos', 'publico'
FROM usuarios
WHERE email LIKE 'nuevo%@example.com';

-- 3.2.3 INSERT con valores calculados:
INSERT INTO reacciones (id_publicacion, id_usuario, tipo_reaccion)
SELECT p.id_publicacion, p.id_usuario, 'like'
FROM publicaciones p
LIMIT 50;

-- 3.2.4 INSERT con manejo de duplicados (UPSERT):
INSERT INTO usuarios (email, password_hash, estado)
VALUES ('duplicado@example.com', 'hash_fake', 'activo')
ON DUPLICATE KEY UPDATE
    estado = 'activo';


------------------------------------------------------------
-- 3.3 OPERACIONES UPDATE
------------------------------------------------------------

-- 3.3.1 UPDATE condicional con CASE
UPDATE usuarios
SET estado = CASE
    WHEN email LIKE '%@example.com' THEN 'activo'
    ELSE 'inactivo'
END;
-- 3.3.2 UPDATE con JOIN:
UPDATE publicaciones p
JOIN usuarios u ON u.id_usuario = p.id_usuario
SET p.visibilidad = 'amigos'
WHERE u.estado = 'inactivo';

-- 3.3.3 UPDATE masivo (todas las publicaciones viejas a 'privado'):
UPDATE publicaciones
SET visibilidad = 'privado'
WHERE fecha_publicacion < NOW() - INTERVAL 1 YEAR;

-- 3.3.4 UPDATE con subconsulta:
UPDATE usuarios
SET estado = 'baneado'
WHERE id_usuario IN (
    SELECT id_usuario
    FROM (
        SELECT p.id_usuario
        FROM publicaciones p
        GROUP BY p.id_usuario
        HAVING COUNT(*) > 1000
    ) t
);

------------------------------------------------------------
-- 3.4 OPERACIONES DELETE
------------------------------------------------------------

-- 3.4.1 Soft delete: marcar usuarios como inactivos en vez de borrarlos
UPDATE usuarios
SET estado = 'inactivo'
WHERE id_usuario IN (SELECT id_usuario FROM usuarios LIMIT 10);
-- 3.4.2 DELETE con subconsulta:
DELETE FROM reacciones
WHERE id_publicacion IN (
    SELECT id_publicacion
    FROM publicaciones
    WHERE fecha_publicacion < NOW() - INTERVAL 2 YEAR
);

-- 3.4.3 DELETE con JOIN:
DELETE c
FROM comentarios c
JOIN publicaciones p ON p.id_publicacion = c.id_publicacion
WHERE p.visibilidad = 'privado';

-- 3.4.4 Archivado antes de eliminación:
-- 1) Tabla de archivo (ejecuta una sola vez)
-- CREATE TABLE IF NOT EXISTS publicaciones_archivo LIKE publicaciones;

-- 2) Archivado + borrado
INSERT INTO publicaciones_archivo
SELECT *
FROM publicaciones
WHERE fecha_publicacion < NOW() - INTERVAL 3 YEAR;

DELETE FROM publicaciones
WHERE fecha_publicacion < NOW() - INTERVAL 3 YEAR;

------------------------------------------------------------
-- 3.5 TRANSACCIONES
------------------------------------------------------------

-- 3.5.1 Ejemplo de transacción con SAVEPOINT y ROLLBACK
START TRANSACTION;
INSERT INTO usuarios (email, password_hash, estado)
VALUES ('transaccion1@example.com', 'hash_fake', 'activo');
SAVEPOINT despues_de_usuario;
INSERT INTO publicaciones (id_usuario, contenido, visibilidad)
SELECT id_usuario, 'Publicación de prueba en transacción', 'publico'
FROM usuarios
WHERE email = 'transaccion1@example.com';

-- Si algo sale mal, se podría hacer:
-- ROLLBACK TO despues_de_usuario;

COMMIT;
-- 3.5.2 Transacción con bloqueo FOR UPDATE y ROLLBACK:
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;

START TRANSACTION;

SELECT id_usuario, email
FROM usuarios
WHERE estado = 'activo'
FOR UPDATE;

UPDATE usuarios
SET estado = 'inactivo'
WHERE email LIKE 'transaccion%@example.com';

-- Simular error: descomentar para probar rollback
-- ROLLBACK;
COMMIT;

