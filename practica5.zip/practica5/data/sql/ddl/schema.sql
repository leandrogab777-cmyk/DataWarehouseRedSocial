-- schema.sql - Modelo red social para práctica 5
-- Base de datos: red_social_db

DROP DATABASE IF EXISTS red_social_db;
CREATE DATABASE red_social_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE red_social_db;

-- Tabla usuarios: credenciales y estado de la cuenta
CREATE TABLE usuarios (
    id_usuario       BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email            VARCHAR(255) NOT NULL UNIQUE,
    password_hash    VARCHAR(255) NOT NULL,
    fecha_registro   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado           ENUM('activo', 'inactivo', 'baneado') NOT NULL DEFAULT 'activo',
    CHECK (estado IN ('activo', 'inactivo', 'baneado'))
) ENGINE=InnoDB;

-- Tabla perfiles: información pública del usuario
CREATE TABLE perfiles (
    id_perfil        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_usuario       BIGINT UNSIGNED NOT NULL,
    nombre           VARCHAR(100) NOT NULL,
    apellido         VARCHAR(100) NOT NULL,
    fecha_nacimiento DATE NULL,
    bio              VARCHAR(500) NULL,
    genero           ENUM('masculino', 'femenino', 'otro') NULL,
    pais             VARCHAR(100) NULL,
    CONSTRAINT fk_perfiles_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Tabla publicaciones: posts de los usuarios
CREATE TABLE publicaciones (
    id_publicacion      BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_usuario          BIGINT UNSIGNED NOT NULL,
    contenido           TEXT NOT NULL,
    fecha_publicacion   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    visibilidad         ENUM('publico', 'amigos', 'privado') NOT NULL DEFAULT 'publico',
    CHECK (visibilidad IN ('publico', 'amigos', 'privado')),
    CONSTRAINT fk_publicaciones_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_publicaciones_usuario_fecha (id_usuario, fecha_publicacion)
) ENGINE=InnoDB;

-- Tabla comentarios: comentarios a publicaciones
CREATE TABLE comentarios (
    id_comentario       BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_publicacion      BIGINT UNSIGNED NOT NULL,
    id_usuario          BIGINT UNSIGNED NOT NULL,
    contenido           TEXT NOT NULL,
    fecha_comentario    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_comentarios_publicacion
        FOREIGN KEY (id_publicacion) REFERENCES publicaciones(id_publicacion)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_comentarios_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_comentarios_pub_fecha (id_publicacion, fecha_comentario)
) ENGINE=InnoDB;

-- Tabla reacciones: likes u otras reacciones a publicaciones
CREATE TABLE reacciones (
    id_reaccion        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_publicacion     BIGINT UNSIGNED NOT NULL,
    id_usuario         BIGINT UNSIGNED NOT NULL,
    tipo_reaccion      ENUM('like', 'love', 'wow', 'triste', 'enojo') NOT NULL DEFAULT 'like',
    fecha_reaccion     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (tipo_reaccion IN ('like', 'love', 'wow', 'triste', 'enojo')),
    CONSTRAINT fk_reacciones_publicacion
        FOREIGN KEY (id_publicacion) REFERENCES publicaciones(id_publicacion)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reacciones_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE ON UPDATE CASCADE,
    -- Evitar que un usuario reaccione dos veces igual a la misma publicación
    UNIQUE KEY uq_reaccion_unica (id_publicacion, id_usuario, tipo_reaccion)
) ENGINE=InnoDB;

-- Tabla seguidores: relaciones de seguimiento entre usuarios
CREATE TABLE seguidores (
    id_seguidor    BIGINT UNSIGNED NOT NULL,
    id_seguido     BIGINT UNSIGNED NOT NULL,
    fecha_inicio   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    activo         TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (id_seguidor, id_seguido),
    CONSTRAINT fk_seguidor_usuario
        FOREIGN KEY (id_seguidor) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_seguido_usuario
        FOREIGN KEY (id_seguido) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;
