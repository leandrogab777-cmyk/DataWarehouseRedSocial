#!/bin/sh

echo "Esperando a que la base de datos esté lista..."

# Esperar hasta que el puerto 3306 esté abierto
until nc -z db 3306; do
  echo "Esperando a MySQL..."
  sleep 2
done

echo "Base de datos lista. Iniciando poblado: leve, moderado y masivo..."

# Poblado leve
python scripts/poblar_leve.py || echo "Error en poblar_leve, pero continúo"

# Poblado moderado
python scripts/poblar_moderado.py || echo "Error en poblar_moderado, pero continúo"

# Poblado masivo
python scripts/poblar_masivo.py || echo "Error en poblar_masivo, pero continúo"

# Mantener el contenedor vivo
tail -f /dev/null
