-- =============================================================================
-- EJERCICIO 5: CONSULTAS OLAP - ANÁLISIS Y REPORTES
-- Mínimo 5 consultas analíticas complejas
-- =============================================================================

USE red_social_db;

-- =============================================================================
-- 5.4.1 ANÁLISIS DE VENTAS POR DIMENSIÓN TEMPORAL
-- Comparar engagement por período (diario, mensual, trimestral)
-- =============================================================================

-- Consulta 1a: Reacciones y engagement por mes
SELECT 
    YEAR(dt.fecha) AS año,
    MONTH(dt.fecha) AS mes,
    dt.nombre_mes,
    COUNT(DISTINCT h.id_producto) AS total_publicaciones,
    SUM(h.cantidad_reacciones) AS total_reacciones,
    SUM(h.cantidad_comentarios) AS total_comentarios,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio,
    SUM(h.alcance_estimado) AS alcance_total
FROM hechos_actividad_social h
JOIN dim_tiempo dt ON h.id_tiempo = dt.id_tiempo
WHERE dt.año = YEAR(CURDATE())
GROUP BY YEAR(dt.fecha), MONTH(dt.fecha), dt.nombre_mes
ORDER BY año DESC, mes DESC;

-- Consulta 1b: Evolución trimestral del engagement
SELECT 
    dt.año,
    dt.trimestre,
    CONCAT('Q', dt.trimestre, ' ', dt.año) AS periodo,
    COUNT(DISTINCT h.id_producto) AS publicaciones,
    SUM(h.cantidad_reacciones) AS reacciones_total,
    SUM(h.cantidad_comentarios) AS comentarios_total,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio,
    ROUND((SUM(h.cantidad_reacciones) + SUM(h.cantidad_comentarios)) / 
          COUNT(DISTINCT h.id_producto), 2) AS ratio_interaccion_pub
FROM hechos_actividad_social h
JOIN dim_tiempo dt ON h.id_tiempo = dt.id_tiempo
GROUP BY dt.año, dt.trimestre
ORDER BY dt.año DESC, dt.trimestre DESC
LIMIT 12;

-- =============================================================================
-- 5.4.2 DRILL-DOWN Y ROLL-UP POR JERARQUÍAS
-- Desagregación y agregación de datos por dimensiones
-- =============================================================================

-- Consulta 2a: Drill-down por región > país > vendedor
SELECT 
    dv.region_principal AS región,
    dv.sucursal AS país,
    dv.nombre_vendedor,
    COUNT(DISTINCT h.id_producto) AS publicaciones,
    SUM(h.cantidad_reacciones) AS total_reacciones,
    SUM(h.cantidad_comentarios) AS total_comentarios,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio,
    dv.nivel_influencia,
    dv.total_followers
FROM hechos_actividad_social h
JOIN dim_vendedor dv ON h.id_vendedor = dv.id_vendedor
WHERE h.id_vendedor IS NOT NULL
GROUP BY dv.region_principal, dv.sucursal, dv.nombre_vendedor, dv.id_vendedor
ORDER BY región, país, total_reacciones DESC;

-- Consulta 2b: Drill-down por categoría > tipo de contenido
SELECT 
    dp.categoria_contenido AS categoría,
    dp.tipo_contenido AS tipo,
    COUNT(DISTINCT h.id_producto) AS cantidad_publicaciones,
    SUM(h.cantidad_reacciones) AS reacciones,
    SUM(h.cantidad_comentarios) AS comentarios,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio,
    ROUND(SUM(h.alcance_estimado) / COUNT(DISTINCT h.id_producto), 2) AS alcance_promedio_pub
FROM hechos_actividad_social h
JOIN dim_producto dp ON h.id_producto = dp.id_producto
GROUP BY dp.categoria_contenido, dp.tipo_contenido
ORDER BY reacciones DESC;

-- Consulta 2c: Roll-up: Resumen por región
SELECT 
    dv.region_principal AS región,
    COUNT(DISTINCT dv.id_vendedor) AS cantidad_vendedores,
    COUNT(DISTINCT h.id_producto) AS total_publicaciones,
    SUM(h.cantidad_reacciones) AS reacciones_región,
    SUM(h.cantidad_comentarios) AS comentarios_región,
    ROUND(AVG(h.engagement_score), 2) AS engagement_región,
    SUM(h.alcance_estimado) AS alcance_región
FROM hechos_actividad_social h
JOIN dim_vendedor dv ON h.id_vendedor = dv.id_vendedor
GROUP BY dv.region_principal
ORDER BY reacciones_región DESC;

-- =============================================================================
-- 5.4.3 ANÁLISIS COMPARATIVO ENTRE PERÍODOS
-- Comparar desempeño mes a mes, año a año, etc.
-- =============================================================================

-- Consulta 3a: Comparación mes actual vs mes anterior (análisis YoY)
SELECT 
    'Mes Actual' AS periodo,
    YEAR(CURDATE()) AS año,
    MONTH(CURDATE()) AS mes,
    COUNT(DISTINCT h.id_producto) AS publicaciones,
    SUM(h.cantidad_reacciones) AS reacciones,
    SUM(h.cantidad_comentarios) AS comentarios,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio
FROM hechos_actividad_social h
JOIN dim_tiempo dt ON h.id_tiempo = dt.id_tiempo
WHERE YEAR(dt.fecha) = YEAR(CURDATE()) 
    AND MONTH(dt.fecha) = MONTH(CURDATE())

UNION ALL

SELECT 
    'Mes Anterior' AS periodo,
    YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AS año,
    MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AS mes,
    COUNT(DISTINCT h.id_producto) AS publicaciones,
    SUM(h.cantidad_reacciones) AS reacciones,
    SUM(h.cantidad_comentarios) AS comentarios,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio
FROM hechos_actividad_social h
JOIN dim_tiempo dt ON h.id_tiempo = dt.id_tiempo
WHERE YEAR(dt.fecha) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))
    AND MONTH(dt.fecha) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH));

-- Consulta 3b: Comparativo trimestral con variación %
WITH trimestres AS (
    SELECT 
        dt.año,
        dt.trimestre,
        SUM(h.cantidad_reacciones) AS reacciones,
        SUM(h.cantidad_comentarios) AS comentarios,
        COUNT(DISTINCT h.id_producto) AS publicaciones
    FROM hechos_actividad_social h
    JOIN dim_tiempo dt ON h.id_tiempo = dt.id_tiempo
    GROUP BY dt.año, dt.trimestre
)
SELECT 
    CONCAT('Q', t1.trimestre, ' ', t1.año) AS trimestre_actual,
    t1.reacciones AS reacciones_actuales,
    COALESCE(t2.reacciones, 0) AS reacciones_previas,
    ROUND(((t1.reacciones - COALESCE(t2.reacciones, 0)) / 
           NULLIF(COALESCE(t2.reacciones, 1), 0)) * 100, 2) AS variacion_reacciones_pct,
    t1.publicaciones AS pubs_actuales,
    COALESCE(t2.publicaciones, 0) AS pubs_previas
FROM trimestres t1
LEFT JOIN trimestres t2 
    ON t1.trimestre = t2.trimestre 
    AND t1.año = t2.año + 1
ORDER BY t1.año DESC, t1.trimestre DESC
LIMIT 8;

-- =============================================================================
-- 5.4.4 TOP N ANÁLISIS
-- Identificar mejores productos, clientes y vendedores
-- =============================================================================

-- Consulta 4a: Top 10 publicaciones más populares
SELECT 
    RANK() OVER (ORDER BY SUM(h.cantidad_reacciones) DESC) AS ranking,
    dp.titulo_publicacion,
    dp.categoria_contenido,
    dv.nombre_vendedor,
    dv.region_principal,
    SUM(h.cantidad_reacciones) AS total_reacciones,
    SUM(h.cantidad_comentarios) AS total_comentarios,
    SUM(h.alcance_estimado) AS alcance_total,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio
FROM hechos_actividad_social h
JOIN dim_producto dp ON h.id_producto = dp.id_producto
JOIN dim_vendedor dv ON h.id_vendedor = dv.id_vendedor
GROUP BY h.id_producto, dp.titulo_publicacion, dp.categoria_contenido, 
         dv.nombre_vendedor, dv.region_principal
ORDER BY total_reacciones DESC
LIMIT 10;

-- Consulta 4b: Top 5 creadores por engagement
SELECT 
    ROW_NUMBER() OVER (ORDER BY total_engagement DESC) AS puesto,
    dv.nombre_vendedor,
    dv.nivel_influencia,
    dv.region_principal,
    dv.total_followers,
    COUNT(DISTINCT h.id_producto) AS total_publicaciones,
    SUM(h.cantidad_reacciones) AS reacciones,
    SUM(h.cantidad_comentarios) AS comentarios,
    SUM(total_engagement) AS total_engagement,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio
FROM (
    SELECT h.*, h.cantidad_reacciones + h.cantidad_comentarios AS total_engagement
    FROM hechos_actividad_social h
) h
JOIN dim_vendedor dv ON h.id_vendedor = dv.id_vendedor
GROUP BY h.id_vendedor, dv.nombre_vendedor, dv.nivel_influencia, 
         dv.region_principal, dv.total_followers
ORDER BY total_engagement DESC
LIMIT 5;

-- Consulta 4c: Top 10 clientes más activos
SELECT 
    ROW_NUMBER() OVER (ORDER BY interacciones_totales DESC) AS ranking,
    dc.nombre_completo,
    dc.segmento_cliente,
    dc.region,
    dc.pais,
    dc.dias_registrado,
    COUNT(DISTINCT h.id_producto) AS productos_consumidos,
    SUM(interacciones_totales) AS interacciones_totales,
    ROUND(AVG(h.engagement_score), 2) AS engagement_consumido
FROM (
    SELECT h.*, h.cantidad_reacciones + h.cantidad_comentarios AS interacciones_totales
    FROM hechos_actividad_social h
) h
JOIN dim_cliente dc ON h.id_cliente = dc.id_cliente
GROUP BY h.id_cliente, dc.nombre_completo, dc.segmento_cliente, 
         dc.region, dc.pais, dc.dias_registrado
ORDER BY interacciones_totales DESC
LIMIT 10;

-- Consulta 4d: Top 5 categorías de contenido
SELECT 
    ROW_NUMBER() OVER (ORDER BY total_reacciones DESC) AS ranking,
    dp.categoria_contenido,
    COUNT(DISTINCT h.id_producto) AS cantidad_publicaciones,
    SUM(h.cantidad_reacciones) AS total_reacciones,
    SUM(h.cantidad_comentarios) AS total_comentarios,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio,
    ROUND(SUM(h.alcance_estimado) / COUNT(DISTINCT h.id_producto), 2) AS alcance_promedio
FROM hechos_actividad_social h
JOIN dim_producto dp ON h.id_producto = dp.id_producto
GROUP BY dp.categoria_contenido
ORDER BY total_reacciones DESC
LIMIT 5;

-- =============================================================================
-- 5.4.5 ANÁLISIS DE TENDENCIAS
-- Identificar patrones, crecimiento, declive
-- =============================================================================

-- Consulta 5a: Tendencia de engagement mensual (últimos 12 meses)
SELECT 
    dt.año,
    dt.mes,
    dt.nombre_mes,
    COUNT(DISTINCT h.id_producto) AS publicaciones,
    SUM(h.cantidad_reacciones) AS reacciones,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio,
    ROUND(SUM(h.alcance_estimado) / COUNT(DISTINCT h.id_producto), 2) AS alcance_promedio,
    ROUND(
        (SUM(h.cantidad_reacciones) - LAG(SUM(h.cantidad_reacciones)) 
            OVER (ORDER BY dt.año, dt.mes)) / 
        NULLIF(LAG(SUM(h.cantidad_reacciones)) 
            OVER (ORDER BY dt.año, dt.mes), 0) * 100, 2
    ) AS tendencia_reacciones_pct
FROM hechos_actividad_social h
JOIN dim_tiempo dt ON h.id_tiempo = dt.id_tiempo
WHERE dt.fecha >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY dt.año, dt.mes, dt.nombre_mes
ORDER BY dt.año, dt.mes;

-- Consulta 5b: Distribución de tipos de reacciones (análisis de sentimiento)
SELECT 
    ROUND(SUM(h.cantidad_likes) * 100.0 / SUM(h.cantidad_reacciones), 2) AS pct_likes,
    ROUND(SUM(h.cantidad_loves) * 100.0 / SUM(h.cantidad_reacciones), 2) AS pct_loves,
    ROUND(SUM(h.cantidad_wow) * 100.0 / SUM(h.cantidad_reacciones), 2) AS pct_wow,
    ROUND(SUM(h.cantidad_triste) * 100.0 / SUM(h.cantidad_reacciones), 2) AS pct_triste,
    ROUND(SUM(h.cantidad_enojo) * 100.0 / SUM(h.cantidad_reacciones), 2) AS pct_enojo,
    SUM(h.cantidad_reacciones) AS total_reacciones
FROM hechos_actividad_social h
WHERE h.cantidad_reacciones > 0;

-- Consulta 5c: Tendencia de crecimiento por región
WITH tendencias_regionales AS (
    SELECT 
        dv.region_principal AS región,
        YEAR(dt.fecha) AS año,
        MONTH(dt.fecha) AS mes,
        SUM(h.cantidad_reacciones) AS reacciones,
        COUNT(DISTINCT h.id_producto) AS publicaciones
    FROM hechos_actividad_social h
    JOIN dim_vendedor dv ON h.id_vendedor = dv.id_vendedor
    JOIN dim_tiempo dt ON h.id_tiempo = dt.id_tiempo
    WHERE dt.fecha >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY dv.region_principal, YEAR(dt.fecha), MONTH(dt.fecha)
)
SELECT 
    región,
    año,
    mes,
    reacciones,
    LAG(reacciones) OVER (PARTITION BY región ORDER BY año, mes) AS reacciones_mes_anterior,
    ROUND((reacciones - LAG(reacciones) OVER (PARTITION BY región ORDER BY año, mes)) / 
          NULLIF(LAG(reacciones) OVER (PARTITION BY región ORDER BY año, mes), 0) * 100, 2) AS crecimiento_pct,
    publicaciones
FROM tendencias_regionales
ORDER BY región, año, mes;

-- Consulta 5d: Segmentación de clientes por comportamiento
SELECT 
    dc.segmento_cliente,
    COUNT(DISTINCT h.id_cliente) AS cantidad_clientes,
    SUM(h.cantidad_reacciones) AS reacciones_totales,
    SUM(h.cantidad_comentarios) AS comentarios_totales,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio,
    ROUND(COUNT(DISTINCT h.id_cliente) * 100.0 / 
          SUM(COUNT(DISTINCT h.id_cliente)) OVER (), 2) AS pct_del_total
FROM hechos_actividad_social h
JOIN dim_cliente dc ON h.id_cliente = dc.id_cliente
WHERE dc.es_activo = 1
GROUP BY dc.segmento_cliente
ORDER BY reacciones_totales DESC;

-- Consulta 5e: Análisis de ciclo de vida de publicaciones
SELECT 
    DATEDIFF(MAX(dt.fecha), MIN(dt.fecha)) AS dias_activos,
    COUNT(DISTINCT h.id_producto) AS cantidad_publicaciones,
    SUM(h.cantidad_reacciones) AS reacciones_totales,
    ROUND(AVG(h.cantidad_reacciones), 2) AS reacciones_promedio,
    SUM(h.cantidad_comentarios) AS comentarios_totales,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio,
    dp.tipo_contenido
FROM hechos_actividad_social h
JOIN dim_tiempo dt ON h.id_tiempo = dt.id_tiempo
JOIN dim_producto dp ON h.id_producto = dp.id_producto
GROUP BY dias_activos, dp.tipo_contenido
HAVING dias_activos > 0
ORDER BY dias_activos DESC;

-- =============================================================================
-- 5.4 CONSULTAS ADICIONALES OLAP AVANZADAS
-- =============================================================================

-- Consulta Bonus 1: Matriz de cruce (Vendedor x Mes)
SELECT 
    dv.nombre_vendedor,
    MAX(CASE WHEN dt.mes = 1 THEN h.cantidad_reacciones ELSE 0 END) AS enero,
    MAX(CASE WHEN dt.mes = 2 THEN h.cantidad_reacciones ELSE 0 END) AS febrero,
    MAX(CASE WHEN dt.mes = 3 THEN h.cantidad_reacciones ELSE 0 END) AS marzo,
    MAX(CASE WHEN dt.mes = 4 THEN h.cantidad_reacciones ELSE 0 END) AS abril,
    MAX(CASE WHEN dt.mes = 5 THEN h.cantidad_reacciones ELSE 0 END) AS mayo,
    MAX(CASE WHEN dt.mes = 6 THEN h.cantidad_reacciones ELSE 0 END) AS junio,
    SUM(h.cantidad_reacciones) AS total
FROM hechos_actividad_social h
JOIN dim_vendedor dv ON h.id_vendedor = dv.id_vendedor
JOIN dim_tiempo dt ON h.id_tiempo = dt.id_tiempo
WHERE dt.año = YEAR(CURDATE())
GROUP BY dv.id_vendedor, dv.nombre_vendedor
LIMIT 10;

-- Consulta Bonus 2: Cubo OLAP - Análisis multi-dimensional
SELECT 
    COALESCE(dv.region_principal, 'TOTAL') AS región,
    COALESCE(dp.categoria_contenido, 'TOTAL') AS categoría,
    COALESCE(dt.trimestre, 0) AS trimestre,
    COUNT(DISTINCT h.id_producto) AS publicaciones,
    SUM(h.cantidad_reacciones) AS reacciones,
    ROUND(AVG(h.engagement_score), 2) AS engagement_promedio
FROM hechos_actividad_social h
JOIN dim_vendedor dv ON h.id_vendedor = dv.id_vendedor
JOIN dim_producto dp ON h.id_producto = dp.id_producto
JOIN dim_tiempo dt ON h.id_tiempo = dt.id_tiempo
WHERE dt.año = YEAR(CURDATE())
GROUP BY dv.region_principal, dp.categoria_contenido, dt.trimestre WITH ROLLUP
ORDER BY región, categoría, trimestre;
