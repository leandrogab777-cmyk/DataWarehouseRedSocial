import mysql.connector
from mysql.connector import Error
import random
from datetime import datetime, timedelta

def crear_conexion():
    return mysql.connector.connect(
        host="db",
        user="root",
        password="rootpassword",
        database="red_social_db"
    )

def poblar_usuarios(cursor, cantidad=50):
    sql = """
        INSERT INTO usuarios (email, password_hash, estado)
        VALUES (%s, %s, %s)
    """
    datos = []
    for i in range(cantidad):
        email = f"user{i}@example.com"
        password_hash = "hash_fake"
        estado = "activo"
        datos.append((email, password_hash, estado))
    cursor.executemany(sql, datos)
    print(f"Inserción de {cantidad} usuarios completada.")

def poblar_perfiles(cursor):
    cursor.execute("SELECT id_usuario FROM usuarios")
    usuarios = [row[0] for row in cursor.fetchall()]
    sql = """
        INSERT INTO perfiles (id_usuario, nombre, apellido, fecha_nacimiento, bio, genero, pais)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """
    datos = []
    for uid in usuarios:
        nombre = f"Nombre{uid}"
        apellido = f"Apellido{uid}"
        fecha_nacimiento = datetime(1990, 1, 1) + timedelta(days=random.randint(0, 10000))
        bio = f"Bio del usuario {uid}"
        genero = random.choice(["masculino", "femenino", "otro"])
        pais = random.choice(["México", "Argentina", "Chile", "Colombia"])
        datos.append((uid, nombre, apellido, fecha_nacimiento.date(), bio, genero, pais))
    cursor.executemany(sql, datos)
    print(f"Inserción de {len(datos)} perfiles completada.")

def poblar_publicaciones(cursor, min_pub=1, max_pub=5):
    cursor.execute("SELECT id_usuario FROM usuarios")
    usuarios = [row[0] for row in cursor.fetchall()]
    sql = """
        INSERT INTO publicaciones (id_usuario, contenido, fecha_publicacion, visibilidad)
        VALUES (%s, %s, %s, %s)
    """
    datos = []
    for uid in usuarios:
        num_pub = random.randint(min_pub, max_pub)
        for _ in range(num_pub):
            contenido = f"Publicación de prueba del usuario {uid}"
            fecha = datetime.now() - timedelta(days=random.randint(0, 365))
            visibilidad = random.choice(["publico", "amigos", "privado"])
            datos.append((uid, contenido, fecha, visibilidad))
    cursor.executemany(sql, datos)
    print(f"Inserción de {len(datos)} publicaciones completada.")

def poblar_seguidores(cursor, max_seguidos_por_usuario=10):
    cursor.execute("SELECT id_usuario FROM usuarios")
    usuarios = [row[0] for row in cursor.fetchall()]
    sql = """
        INSERT INTO seguidores (id_seguidor, id_seguido, activo)
        VALUES (%s, %s, %s)
    """
    datos = []
    for seguidor in usuarios:
        posibles_seguidos = [u for u in usuarios if u != seguidor]
        num_seguidos = min(len(posibles_seguidos), max_seguidos_por_usuario)
        seguidos = random.sample(posibles_seguidos, num_seguidos)
        for seguido in seguidos:
            datos.append((seguidor, seguido, 1))
    cursor.executemany(sql, datos)
    print(f"Inserción de {len(datos)} relaciones de seguidores completada.")

def main():
    conn = None
    cursor = None
    try:
        conn = crear_conexion()
        conn.autocommit = False
        cursor = conn.cursor()

        poblar_usuarios(cursor, cantidad=50)
        poblar_perfiles(cursor)
        poblar_publicaciones(cursor)
        poblar_seguidores(cursor)

        conn.commit()
        print("Poblado leve completado (transacción confirmada).")

    except Error as e:
        print("Error durante el poblado:", e)
        if conn:
            conn.rollback()
            print("Transacción revertida por error.")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

if __name__ == "__main__":
    main()
