#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EJERCICIO 5: PROCESO ETL PARA DATA WAREHOUSE
Implementación completa de Extract, Transform, Load
Autor: Universidad
Fecha: 2025
"""

import mysql.connector
from mysql.connector import Error
import logging
import time
from datetime import datetime, timedelta
from typing import List, Tuple, Dict
import json

# =============================================================================
# CONFIGURACIÓN DE LOGGING
# =============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('etl_warehouse.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# =============================================================================
# CONFIGURACIÓN DE BASE DE DATOS
# =============================================================================

DB_CONFIG = {
    'host': 'db',
    'user': 'root',
    'password': 'rootpassword',
    'database': 'red_social_db'
}

# =============================================================================
# CLASE PRINCIPAL: ETL_DataWarehouse
# =============================================================================

class ETL_DataWarehouse:
    """Gestor del proceso ETL completo para el Data Warehouse"""
    
    def __init__(self, config: Dict):
        """Inicializa la conexión a la base de datos"""
        self.config = config
        self.conexion = None
        self.cursor = None
        self.id_ejecucion = None
        
    def conectar(self) -> bool:
        """Establece conexión a la BD"""
        try:
            self.conexion = mysql.connector.connect(**self.config)
            self.cursor = self.conexion.cursor()
            logger.info("✓ Conexión a base de datos establecida")
            return True
        except Error as e:
            logger.error(f"✗ Error de conexión: {e}")
            return False
    
    def desconectar(self):
        """Cierra la conexión"""
        if self.cursor:
            self.cursor.close()
        if self.conexion:
            self.conexion.close()
        logger.info("✓ Conexión cerrada")
    
    def registrar_etl_log(self, nombre_proceso: str, tipo: str, 
                          cantidad_registros: int = 0, 
                          cantidad_insertados: int = 0,
                          cantidad_errores: int = 0,
                          estado: str = 'en_progreso',
                          mensaje_error: str = None):
        """Registra la ejecución del ETL en la tabla de auditoría"""
        try:
            if not self.id_ejecucion:
                sql = """
                INSERT INTO etl_ejecucion_log 
                (nombre_proceso, tipo_operacion, fecha_inicio, cantidad_registros_procesados, estado)
                VALUES (%s, %s, %s, %s, %s)
                """
                self.cursor.execute(sql, (nombre_proceso, tipo, datetime.now(), cantidad_registros, estado))
                self.conexion.commit()
                self.id_ejecucion = self.cursor.lastrowid
                logger.info(f"  → Registro ETL iniciado (ID: {self.id_ejecucion})")
            else:
                sql = """
                UPDATE etl_ejecucion_log
                SET cantidad_registros_procesados = %s,
                    cantidad_registros_insertados = %s,
                    cantidad_errores = %s,
                    estado = %s,
                    mensaje_error = %s,
                    fecha_fin = CASE WHEN %s = 'completado' THEN NOW() ELSE fecha_fin END
                WHERE id_ejecucion = %s
                """
                self.cursor.execute(sql, (cantidad_registros, cantidad_insertados, 
                                          cantidad_errores, estado, mensaje_error,
                                          estado, self.id_ejecucion))
                self.conexion.commit()
        except Exception as e:
            logger.error(f"  ✗ Error registrando ETL log: {e}")
    
    # ==========================================================================
    # FASE 1: EXTRACT - Extrae datos de tablas OLTP
    # ==========================================================================
    
    def extract_dimensiones(self) -> Dict[str, List]:
        """
        EXTRACT: Lee datos de tablas OLTP normalizadas
        Identifica registros nuevos desde última carga
        """
        logger.info("\n" + "="*70)
        logger.info("FASE 1: EXTRACT - Lectura de datos OLTP")
        logger.info("="*70)
        
        try:
            datos = {
                'usuarios': [],
                'publicaciones': [],
                'reacciones': [],
                'comentarios': [],
                'seguidores': []
            }
            
            # Extract Usuarios
            logger.info("→ Extrayendo usuarios...")
            sql = """
SELECT 
    u.id_usuario,
    u.email,
    p.nombre,
    p.apellido,
    p.pais,
    u.fecha_registro,
    u.estado,
    COUNT(DISTINCT s.id_seguido) as total_followers
FROM usuarios u
LEFT JOIN perfiles p ON u.id_usuario = p.id_usuario
LEFT JOIN seguidores s ON u.id_usuario = s.id_seguido AND s.activo = 1
WHERE u.estado = 'activo'
GROUP BY 
    u.id_usuario,
    u.email,
    p.nombre,
    p.apellido,
    p.pais,
    u.fecha_registro,
    u.estado
"""
            self.cursor.execute(sql)
            datos['usuarios'] = self.cursor.fetchall()
            logger.info(f"  ✓ {len(datos['usuarios'])} usuarios extraídos")
            
            # Extract Publicaciones
            logger.info("→ Extrayendo publicaciones...")
            sql = """
            SELECT 
                p.id_publicacion,
                p.id_usuario,
                p.contenido,
                p.fecha_publicacion,
                p.visibilidad,
                LENGTH(p.contenido) as longitud
            FROM publicaciones p
            WHERE p.id_usuario IN (SELECT id_usuario FROM usuarios WHERE estado = 'activo')
            ORDER BY p.fecha_publicacion
            """
            self.cursor.execute(sql)
            datos['publicaciones'] = self.cursor.fetchall()
            logger.info(f"  ✓ {len(datos['publicaciones'])} publicaciones extraídas")
            
            # Extract Reacciones
            logger.info("→ Extrayendo reacciones...")
            sql = """
            SELECT 
                r.id_reaccion,
                r.id_publicacion,
                r.id_usuario,
                r.tipo_reaccion,
                r.fecha_reaccion
            FROM reacciones r
            JOIN publicaciones p ON r.id_publicacion = p.id_publicacion
            WHERE p.id_usuario IN (SELECT id_usuario FROM usuarios WHERE estado = 'activo')
            """
            self.cursor.execute(sql)
            datos['reacciones'] = self.cursor.fetchall()
            logger.info(f"  ✓ {len(datos['reacciones'])} reacciones extraídas")
            
            # Extract Comentarios
            logger.info("→ Extrayendo comentarios...")
            sql = """
            SELECT 
                c.id_comentario,
                c.id_publicacion,
                c.id_usuario,
                c.fecha_comentario,
                LENGTH(c.contenido) as longitud_comentario
            FROM comentarios c
            JOIN publicaciones p ON c.id_publicacion = p.id_publicacion
            WHERE p.id_usuario IN (SELECT id_usuario FROM usuarios WHERE estado = 'activo')
            """
            self.cursor.execute(sql)
            datos['comentarios'] = self.cursor.fetchall()
            logger.info(f"  ✓ {len(datos['comentarios'])} comentarios extraídos")
            
            # Extract Seguidores
            logger.info("→ Extrayendo relaciones de seguidores...")
            sql = """
            SELECT 
                id_seguidor,
                id_seguido,
                fecha_inicio,
                activo
            FROM seguidores
            WHERE activo = 1
            """
            self.cursor.execute(sql)
            datos['seguidores'] = self.cursor.fetchall()
            logger.info(f"  ✓ {len(datos['seguidores'])} relaciones de seguidores extraídas")
            
            self.registrar_etl_log('EXTRACT_GENERAL', 'Extract',
                                   cantidad_registros=sum(len(v) for v in datos.values()),
                                   estado='en_progreso')
            
            return datos
            
        except Error as e:
            logger.error(f"✗ Error durante EXTRACT: {e}")
            self.registrar_etl_log('EXTRACT_GENERAL', 'Extract',
                                   estado='error',
                                   mensaje_error=str(e))
            raise
    
    # ==========================================================================
    # FASE 2: TRANSFORM - Limpia, valida y enriquece datos
    # ==========================================================================
    
    def transform_datos(self, datos: Dict[str, List]) -> Dict[str, List]:
        """
        TRANSFORM: 
        - Limpia y valida datos
        - Calcula métricas derivadas
        - Enriquece datos con información calculada
        """
        logger.info("\n" + "="*70)
        logger.info("FASE 2: TRANSFORM - Limpieza, validación y enriquecimiento")
        logger.info("="*70)
        
        try:
            transformados = {
                'dim_tiempo': [],
                'dim_cliente': [],
                'dim_producto': [],
                'dim_vendedor': [],
                'hechos': []
            }
            
            # TRANSFORM dim_tiempo: Generar todas las fechas necesarias
            logger.info("→ Transformando dimensión TIEMPO...")
            todas_fechas = set()
            for pub in datos['publicaciones']:
                todas_fechas.add(pub[3].date())
            for rec in datos['reacciones']:
                todas_fechas.add(rec[4].date())
            
            for fecha in sorted(todas_fechas):
                transformados['dim_tiempo'].append({
                    'fecha': fecha,
                    'dia': fecha.day,
                    'mes': fecha.month,
                    'trimestre': (fecha.month - 1) // 3 + 1,
                    'anio': fecha.year,
                    'nombre_mes': self._get_nombre_mes(fecha.month),
                    'nombre_dia_semana': self._get_nombre_dia(fecha.weekday()),
                    'es_fin_semana': 1 if fecha.weekday() >= 5 else 0
                })
            logger.info(f"  ✓ {len(transformados['dim_tiempo'])} registros de tiempo")
            
            # TRANSFORM dim_cliente
            logger.info("→ Transformando dimensión CLIENTE...")
            dias_hoy = datetime.now().date()
            for usuario in datos['usuarios']:
                id_usuario, email, nombre, apellido, pais, fecha_reg, estado, followers = usuario
                
                dias_registrado = (dias_hoy - fecha_reg.date()).days if fecha_reg else 0
                segmento = self._calcular_segmento_cliente(followers, dias_registrado)
                region = self._asignar_region(pais or 'Desconocido')
                
                transformados['dim_cliente'].append({
                    'id_usuario': id_usuario,
                    'nombre_completo': f"{nombre or ''} {apellido or ''}".strip() or email,
                    'email': email,
                    'pais': pais or 'Desconocido',
                    'region': region,
                    'segmento_cliente': segmento,
                    'dias_registrado': dias_registrado,
                    'estado_actual': estado,
                    'es_activo': 1 if estado == 'activo' else 0
                })
            logger.info(f"  ✓ {len(transformados['dim_cliente'])} clientes transformados")
            
            # TRANSFORM dim_producto
            logger.info("→ Transformando dimensión PRODUCTO...")
            for pub in datos['publicaciones']:
                id_pub, id_usuario, contenido, fecha, visibilidad, longitud = pub
                
                categoria = self._categorizar_contenido(contenido)
                tipo = self._clasificar_tipo_contenido(contenido, longitud)
                
                transformados['dim_producto'].append({
                    'id_publicacion': id_pub,
                    'titulo_publicacion': contenido[:500] if contenido else 'Sin título',
                    'categoria_contenido': categoria,
                    'tipo_contenido': tipo,
                    'longitud_contenido': longitud or 0,
                    'visibilidad': visibilidad
                })
            logger.info(f"  ✓ {len(transformados['dim_producto'])} productos/publicaciones")
            
            # TRANSFORM dim_vendedor
            logger.info("→ Transformando dimensión VENDEDOR...")
            vendedores_set = set(pub[1] for pub in datos['publicaciones'])
            usuarios_dict = {u[0]: u for u in datos['usuarios']}
            
            for id_vendedor in vendedores_set:
                usuario = usuarios_dict.get(id_vendedor)
                if usuario:
                    id_u, email, nombre, apellido, pais, fecha_reg, estado, followers = usuario
                    
                    pubs_vendedor = [p for p in datos['publicaciones'] if p[1] == id_vendedor]
                    pubs_publicas = sum(1 for p in pubs_vendedor if p[4] == 'publico')
                    
                    porcentaje_publico = (pubs_publicas / len(pubs_vendedor) * 100) if pubs_vendedor else 0
                    nivel_influencia = self._calcular_nivel_influencia(followers)
                    region = self._asignar_region(pais or 'Desconocido')
                    
                    transformados['dim_vendedor'].append({
                        'id_usuario_creador': id_vendedor,
                        'nombre_vendedor': f"{nombre or ''} {apellido or ''}".strip() or email,
                        'email_vendedor': email,
                        'region_principal': region,
                        'sucursal': pais or 'Desconocido',
                        'nivel_influencia': nivel_influencia,
                        'total_followers': followers,
                        'porcentaje_contenido_publico': porcentaje_publico
                    })
            logger.info(f"  ✓ {len(transformados['dim_vendedor'])} vendedores/creadores")
            
            # TRANSFORM Hechos - CON MAPEO CORRECTO DE TIPOS DE REACCIÓN
            logger.info("→ Transformando TABLA DE HECHOS...")
            hechos_dict = {}
            
            # Mapeo de tipo_reaccion a campo en la tabla de hechos
            mapa_reacciones = {
                'like': 'cantidad_likes',
                'love': 'cantidad_loves',
                'wow': 'cantidad_wow',
                'triste': 'cantidad_triste',
                'enojo': 'cantidad_enojo'
            }
            
            for reaccion in datos['reacciones']:
                id_rec, id_pub, id_usuario, tipo_rec, fecha_rec = reaccion
                pub = next((p for p in datos['publicaciones'] if p[0] == id_pub), None)
                
                if pub:
                    fecha_key = pub[3].date()
                    key = (id_pub, pub[1], fecha_key)
                    
                    if key not in hechos_dict:
                        hechos_dict[key] = {
                            'id_publicacion': id_pub,
                            'id_usuario_creador': pub[1],
                            'fecha': fecha_key,
                            'cantidad_reacciones': 0,
                            'cantidad_comentarios': 0,
                            'cantidad_likes': 0,
                            'cantidad_loves': 0,
                            'cantidad_wow': 0,
                            'cantidad_triste': 0,
                            'cantidad_enojo': 0,
                            'alcance_estimado': 0
                        }
                    
                    hechos_dict[key]['cantidad_reacciones'] += 1
                    
                    # Incrementar el contador específico del tipo de reacción
                    if tipo_rec in mapa_reacciones:
                        campo = mapa_reacciones[tipo_rec]
                        hechos_dict[key][campo] += 1
            
            # Agregar comentarios a hechos
            for comentario in datos['comentarios']:
                id_com, id_pub, id_usuario, fecha_com, longitud = comentario
                pub = next((p for p in datos['publicaciones'] if p[0] == id_pub), None)
                
                if pub:
                    fecha_key = pub[3].date()
                    key = (id_pub, pub[1], fecha_key)
                    
                    if key not in hechos_dict:
                        hechos_dict[key] = {
                            'id_publicacion': id_pub,
                            'id_usuario_creador': pub[1],
                            'fecha': fecha_key,
                            'cantidad_reacciones': 0,
                            'cantidad_comentarios': 0,
                            'cantidad_likes': 0,
                            'cantidad_loves': 0,
                            'cantidad_wow': 0,
                            'cantidad_triste': 0,
                            'cantidad_enojo': 0,
                            'alcance_estimado': 0
                        }
                    
                    hechos_dict[key]['cantidad_comentarios'] += 1
            
            # Calcular engagement_score y alcance
            for key, hecho in hechos_dict.items():
                reacciones = hecho['cantidad_reacciones']
                comentarios = hecho['cantidad_comentarios']
                hecho['engagement_score'] = (reacciones * 1 + comentarios * 2)
                hecho['alcance_estimado'] = int(reacciones + comentarios * 1.5)
                transformados['hechos'].append(hecho)
            
            logger.info(f"  ✓ {len(transformados['hechos'])} registros de hechos generados")
            
            self.registrar_etl_log('TRANSFORM_GENERAL', 'Transform',
                                   cantidad_registros=len(transformados['dim_tiempo']),
                                   estado='en_progreso')
            
            return transformados
            
        except Exception as e:
            logger.error(f"✗ Error durante TRANSFORM: {e}")
            self.registrar_etl_log('TRANSFORM_GENERAL', 'Transform',
                                   estado='error',
                                   mensaje_error=str(e))
            raise
    
    # ==========================================================================
    # FASE 3: LOAD - Carga datos en tablas de Data Warehouse
    # ==========================================================================
    
    def load_datos(self, datos_transformados: Dict[str, List]):
        """
        LOAD:
        - Inserta en dimensiones
        - Inserta en tabla de hechos
        - Actualiza agregados
        """
        logger.info("\n" + "="*70)
        logger.info("FASE 3: LOAD - Carga en Data Warehouse")
        logger.info("="*70)
        
        try:
            total_insertados = 0
            
            # TIEMPO
            logger.info("→ Cargando dimensión TIEMPO...")
            total_insertados += self._load_dim_tiempo(datos_transformados['dim_tiempo'])
            
            # CLIENTE
            logger.info("→ Cargando dimensión CLIENTE...")
            clientes_map = self._load_dim_cliente(datos_transformados['dim_cliente'])
            total_insertados += len(clientes_map)
            
            # PRODUCTO
            logger.info("→ Cargando dimensión PRODUCTO...")
            productos_map = self._load_dim_producto(datos_transformados['dim_producto'])
            total_insertados += len(productos_map)
            
            # VENDEDOR
            logger.info("→ Cargando dimensión VENDEDOR...")
            vendedores_map = self._load_dim_vendedor(datos_transformados['dim_vendedor'])
            total_insertados += len(vendedores_map)
            
            # HECHOS
            logger.info("→ Cargando TABLA DE HECHOS...")
            hechos_insertados = self._load_hechos(datos_transformados['hechos'], 
                                                  clientes_map, productos_map, 
                                                  vendedores_map)
            total_insertados += hechos_insertados
            
            logger.info(f"✓ LOAD completado: {total_insertados} registros insertados")
            
            self.registrar_etl_log('LOAD_GENERAL', 'Load',
                                   cantidad_insertados=total_insertados,
                                   estado='completado')
            
        except Exception as e:
            logger.error(f"✗ Error durante LOAD: {e}")
            self.registrar_etl_log('LOAD_GENERAL', 'Load',
                                   cantidad_errores=1,
                                   estado='error',
                                   mensaje_error=str(e))
            raise
    
    def _load_dim_tiempo(self, dim_tiempo: List[Dict]) -> int:
        """Carga dimensión de tiempo"""
        sql = """
        INSERT INTO dim_tiempo (fecha, dia, mes, trimestre, anio, nombre_mes, nombre_dia_semana, es_fin_semana)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE 
            dia = VALUES(dia),
            mes = VALUES(mes),
            trimestre = VALUES(trimestre),
            anio = VALUES(anio),
            nombre_mes = VALUES(nombre_mes),
            nombre_dia_semana = VALUES(nombre_dia_semana),
            es_fin_semana = VALUES(es_fin_semana)
        """
        
        datos = [(d['fecha'], d['dia'], d['mes'], d['trimestre'], d['anio'],
                  d['nombre_mes'], d['nombre_dia_semana'], d['es_fin_semana'])
                 for d in dim_tiempo]
        
        if datos:
            self.cursor.executemany(sql, datos)
            self.conexion.commit()
        logger.info(f"  ✓ {len(datos)} registros de tiempo cargados")
        return len(datos)
    
    def _load_dim_cliente(self, dim_cliente: List[Dict]) -> Dict:
        """Carga dimensión de cliente y retorna mapeo id_usuario -> id_cliente"""
        sql = """
        INSERT INTO dim_cliente (id_usuario, nombre_completo, email, pais, region, 
                                segmento_cliente, dias_registrado, estado_actual, es_activo)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE 
            nombre_completo = VALUES(nombre_completo),
            segmento_cliente = VALUES(segmento_cliente),
            dias_registrado = VALUES(dias_registrado),
            estado_actual = VALUES(estado_actual)
        """
        
        datos = [(c['id_usuario'], c['nombre_completo'], c['email'], c['pais'],
                  c['region'], c['segmento_cliente'], c['dias_registrado'],
                  c['estado_actual'], c['es_activo'])
                 for c in dim_cliente]
        
        if datos:
            self.cursor.executemany(sql, datos)
            self.conexion.commit()
        
        mapa = {}
        for cliente in dim_cliente:
            sql_select = "SELECT id_cliente FROM dim_cliente WHERE id_usuario = %s"
            self.cursor.execute(sql_select, (cliente['id_usuario'],))
            resultado = self.cursor.fetchone()
            if resultado:
                mapa[cliente['id_usuario']] = resultado[0]
        
        logger.info(f"  ✓ {len(datos)} clientes cargados")
        return mapa
    
    def _load_dim_producto(self, dim_producto: List[Dict]) -> Dict:
        """Carga dimensión de producto y retorna mapeo"""
        sql = """
        INSERT INTO dim_producto (id_publicacion, titulo_publicacion, categoria_contenido,
                                 tipo_contenido, longitud_contenido, visibilidad)
        VALUES (%s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE 
            titulo_publicacion = VALUES(titulo_publicacion),
            categoria_contenido = VALUES(categoria_contenido)
        """
        
        datos = [(p['id_publicacion'], p['titulo_publicacion'], p['categoria_contenido'],
                  p['tipo_contenido'], p['longitud_contenido'], p['visibilidad'])
                 for p in dim_producto]
        
        if datos:
            self.cursor.executemany(sql, datos)
            self.conexion.commit()
        
        mapa = {}
        for producto in dim_producto:
            sql_select = "SELECT id_producto FROM dim_producto WHERE id_publicacion = %s"
            self.cursor.execute(sql_select, (producto['id_publicacion'],))
            resultado = self.cursor.fetchone()
            if resultado:
                mapa[producto['id_publicacion']] = resultado[0]
        
        logger.info(f"  ✓ {len(datos)} productos cargados")
        return mapa
    
    def _load_dim_vendedor(self, dim_vendedor: List[Dict]) -> Dict:
        """Carga dimensión de vendedor"""
        sql = """
        INSERT INTO dim_vendedor (id_usuario_creador, nombre_vendedor, email_vendedor,
                                 region_principal, sucursal, nivel_influencia,
                                 total_followers, porcentaje_contenido_publico)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE 
            nombre_vendedor = VALUES(nombre_vendedor),
            nivel_influencia = VALUES(nivel_influencia),
            total_followers = VALUES(total_followers)
        """
        
        datos = [(v['id_usuario_creador'], v['nombre_vendedor'], v['email_vendedor'],
                  v['region_principal'], v['sucursal'], v['nivel_influencia'],
                  v['total_followers'], v['porcentaje_contenido_publico'])
                 for v in dim_vendedor]
        
        if datos:
            self.cursor.executemany(sql, datos)
            self.conexion.commit()
        
        mapa = {}
        for vendedor in dim_vendedor:
            sql_select = "SELECT id_vendedor FROM dim_vendedor WHERE id_usuario_creador = %s"
            self.cursor.execute(sql_select, (vendedor['id_usuario_creador'],))
            resultado = self.cursor.fetchone()
            if resultado:
                mapa[vendedor['id_usuario_creador']] = resultado[0]
        
        logger.info(f"  ✓ {len(datos)} vendedores cargados")
        return mapa
    
    def _load_hechos(self, hechos: List[Dict], clientes_map: Dict, 
                     productos_map: Dict, vendedores_map: Dict) -> int:
        """Carga tabla de hechos (1 INSERT por fila, evitando problemas de multi-row)"""
        sql = """
        INSERT INTO hechos_actividad_social 
        (id_tiempo, id_producto, id_cliente, id_vendedor,
         cantidad_reacciones, cantidad_comentarios, cantidad_likes, cantidad_loves,
         cantidad_wow, cantidad_triste, cantidad_enojo, engagement_score, alcance_estimado)
        VALUES (
            (SELECT id_tiempo FROM dim_tiempo WHERE fecha = %s),
            %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s, %s, %s
        )
        ON DUPLICATE KEY UPDATE
            cantidad_reacciones = VALUES(cantidad_reacciones),
            cantidad_comentarios = VALUES(cantidad_comentarios),
            cantidad_likes = VALUES(cantidad_likes),
            cantidad_loves = VALUES(cantidad_loves),
            cantidad_wow = VALUES(cantidad_wow),
            cantidad_triste = VALUES(cantidad_triste),
            cantidad_enojo = VALUES(cantidad_enojo),
            engagement_score = VALUES(engagement_score),
            alcance_estimado = VALUES(alcance_estimado)
        """

        filas_insertadas = 0

        for hecho in hechos:
            id_cliente = clientes_map.get(hecho['id_usuario_creador'])
            id_producto = productos_map.get(hecho['id_publicacion'])
            id_vendedor = vendedores_map.get(hecho['id_usuario_creador'])

            # Si falta alguna FK, se salta
            if not (id_cliente and id_producto and id_vendedor):
                continue

            params = (
                hecho['fecha'],                 # para subquery de id_tiempo
                id_producto,
                id_cliente,
                id_vendedor,
                hecho['cantidad_reacciones'],
                hecho['cantidad_comentarios'],
                hecho.get('cantidad_likes', 0),
                hecho.get('cantidad_loves', 0),
                hecho.get('cantidad_wow', 0),
                hecho.get('cantidad_triste', 0),
                hecho.get('cantidad_enojo', 0),
                hecho['engagement_score'],
                hecho['alcance_estimado']
            )

            try:
                self.cursor.execute(sql, params)
                filas_insertadas += 1
            except Exception as e:
                logger.warning(f"  ⚠ Fila de hecho omitida: {e}")
                continue

        if filas_insertadas > 0:
            self.conexion.commit()

        logger.info(f"  ✓ {filas_insertadas} registros de hechos cargados")
        return filas_insertadas
    
    # ==========================================================================
    # FUNCIONES AUXILIARES DE TRANSFORMACIÓN
    # ==========================================================================
    
    @staticmethod
    def _get_nombre_mes(mes: int) -> str:
        meses = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
        return meses[mes] if 1 <= mes <= 12 else 'Desconocido'
    
    @staticmethod
    def _get_nombre_dia(dia_semana: int) -> str:
        dias = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo']
        return dias[dia_semana] if 0 <= dia_semana < 7 else 'Desconocido'
    
    @staticmethod
    def _calcular_segmento_cliente(followers: int, dias_registrado: int) -> str:
        if followers >= 500:
            return 'VIP'
        elif followers >= 100:
            return 'Premium'
        elif dias_registrado >= 365:
            return 'Fiel'
        elif dias_registrado >= 90:
            return 'Activo'
        else:
            return 'Nuevo'
    
    @staticmethod
    def _asignar_region(pais: str) -> str:
        regiones = {
            'México': 'Norteamérica',
            'Argentina': 'Sudamérica',
            'Chile': 'Sudamérica',
            'Colombia': 'Sudamérica',
            'Brasil': 'Sudamérica',
            'Peru': 'Sudamérica',
        }
        return regiones.get(pais, 'Latinoamérica')
    
    @staticmethod
    def _categorizar_contenido(contenido: str) -> str:
        contenido_lower = contenido.lower() if contenido else ''
        
        if 'foto' in contenido_lower or 'imagen' in contenido_lower:
            return 'Visual'
        elif 'video' in contenido_lower:
            return 'Multimedia'
        elif 'noticia' in contenido_lower or 'noticias' in contenido_lower:
            return 'Noticias'
        elif 'preguntar' in contenido_lower or '¿' in (contenido or ''):
            return 'Interacción'
        else:
            return 'General'
    
    @staticmethod
    def _clasificar_tipo_contenido(contenido: str, longitud: int) -> str:
        if longitud is None or longitud == 0:
            return 'texto'
        elif longitud < 200:
            return 'texto'
        elif longitud < 1000:
            return 'hibrido'
        else:
            return 'multimedia'
    
    @staticmethod
    def _calcular_nivel_influencia(followers: int) -> str:
        if followers >= 1000:
            return 'Influencer'
        elif followers >= 500:
            return 'Micro Influencer'
        elif followers >= 100:
            return 'Popular'
        else:
            return 'Regular'
    
    # ==========================================================================
    # PROCESO PRINCIPAL
    # ==========================================================================
    
    def ejecutar_etl_completo(self):
        inicio = time.time()
        
        try:
            logger.info("\n")
            logger.info("*" * 70)
            logger.info("INICIANDO PROCESO ETL - DATA WAREHOUSE")
            logger.info("*" * 70)
            
            datos_extraidos = self.extract_dimensiones()
            datos_transformados = self.transform_datos(datos_extraidos)
            self.load_datos(datos_transformados)
            
            duracion = time.time() - inicio
            
            logger.info("\n" + "="*70)
            logger.info("✓ PROCESO ETL COMPLETADO EXITOSAMENTE")
            logger.info("="*70)
            logger.info(f"Duración total: {duracion:.2f} segundos")
            
        except Exception as e:
            logger.error(f"\n✗ Error fatal en ETL: {e}")
            raise

# =============================================================================
# FUNCIÓN PRINCIPAL
# =============================================================================

def main():
    etl = ETL_DataWarehouse(DB_CONFIG)
    
    try:
        if etl.conectar():
            etl.ejecutar_etl_completo()
        else:
            logger.error("No se pudo establecer conexión a la BD")
    
    except Exception as e:
        logger.error(f"Error fatal: {e}")
    
    finally:
        etl.desconectar()

if __name__ == '__main__':
    main()
