import mysql.connector
from mysql.connector import Error
import csv
import os
import random
import time
from datetime import datetime, timedelta
print("[MASIVO] INICIANDO poblar_masivo.py")

CSV_USUARIOS = "data/usuarios_masivo.csv"
CSV_PUBLICACIONES = "data/publicaciones_masivo.csv"

N_USUARIOS = 100_000
MIN_PUB = 3
MAX_PUB = 5

def crear_conexion():
    return mysql.connector.connect(
        host="db",
        user="root",
        password="rootpassword",
        database="red_social_db",
        allow_local_infile=True
    )

def generar_csv_usuarios():
    os.makedirs("data", exist_ok=True)
    with open(CSV_USUARIOS, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        for i in range(N_USUARIOS):
            email = f"user_x{i}@example.com"
            password_hash = "hash_fake"
            estado = "activo"
            writer.writerow([email, password_hash, estado])
    print(f"[MASIVO] CSV de usuarios generado: {N_USUARIOS} filas.")

def cargar_usuarios(cursor):
    sql = f"""
        LOAD DATA LOCAL INFILE '{CSV_USUARIOS}'
        INTO TABLE usuarios
        FIELDS TERMINATED BY ','
        LINES TERMINATED BY '\\n'
        (email, password_hash, estado);
    """
    cursor.execute("SET GLOBAL local_infile = 1;")
    cursor.execute(sql)
    print("[MASIVO] Usuarios cargados con LOAD DATA INFILE.")

def obtener_ids_usuarios(cursor):
    cursor.execute("SELECT id_usuario FROM usuarios ORDER BY id_usuario")
    return [row[0] for row in cursor.fetchall()]

def generar_csv_publicaciones(ids_usuarios):
    with open(CSV_PUBLICACIONES, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        for uid in ids_usuarios:
            n_pub = random.randint(MIN_PUB, MAX_PUB)
            for _ in range(n_pub):
                contenido = f"[MASIVO] Publicación del usuario {uid}"
                fecha = (datetime.now() - timedelta(days=random.randint(0, 365))).strftime("%Y-%m-%d %H:%M:%S")
                visibilidad = random.choice(["publico", "amigos", "privado"])
                writer.writerow([uid, contenido, fecha, visibilidad])
    print("[MASIVO] CSV de publicaciones generado.")

def cargar_publicaciones(cursor):
    sql = f"""
        LOAD DATA LOCAL INFILE '{CSV_PUBLICACIONES}'
        INTO TABLE publicaciones
        FIELDS TERMINATED BY ','
        LINES TERMINATED BY '\\n'
        (id_usuario, contenido, fecha_publicacion, visibilidad);
    """
    cursor.execute(sql)
    print("[MASIVO] Publicaciones cargadas con LOAD DATA INFILE.")

def main():
    conn = None
    cursor = None
    try:
        inicio = time.time()
        # generar_csv_usuarios()  # Commented out to avoid generating CSV

        conn = crear_conexion()
        conn.autocommit = False
        cursor = conn.cursor()

        # cargar_usuarios(cursor)  # Commented out since no CSV
        ids = obtener_ids_usuarios(cursor)
        # generar_csv_publicaciones(ids)  # Commented out to avoid generating CSV
        # cargar_publicaciones(cursor)  # Commented out since no CSV

        conn.commit()
        fin = time.time()
        print(f"[MASIVO] Poblado masivo completado en {fin - inicio:.2f} segundos.")

    except Error as e:
        print("[MASIVO] Error durante el poblado:", e)
        if conn:
            conn.rollback()
            print("[MASIVO] Transacción revertida por error.")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

if __name__ == "__main__":
    main()
