-- =============================================================================
-- EJERCICIO 5: DATA WAREHOUSE - SCHEMA DDL
-- Modelo Dimensional (Star Schema) para análisis OLAP
-- =============================================================================

USE red_social_db;

-- =============================================================================
-- 5.2.1 DIMENSIÓN: TIEMPO
-- Jerarquía: Año > Trimestre > Mes > Día
-- =============================================================================

CREATE TABLE IF NOT EXISTS dim_tiempo (
    id_tiempo INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    fecha DATE NOT NULL UNIQUE,
    dia INT NOT NULL,
    mes INT NOT NULL,
    trimestre INT NOT NULL,
    anio INT NOT NULL,
    nombre_mes VARCHAR(20) NOT NULL,
    nombre_dia_semana VARCHAR(15) NOT NULL,
    es_fin_semana TINYINT(1) NOT NULL DEFAULT 0,
    INDEX idx_anio_mes (anio, mes),
    INDEX idx_trimestre (trimestre),
    INDEX idx_fecha (fecha)
) ENGINE=InnoDB COMMENT='Dimensión de tiempo con jerarquía temporal';

-- =============================================================================
-- 5.2.2 DIMENSIÓN: PRODUCTO (Adaptada a publicaciones)
-- Jerarquía: Categoría > Tipo > ID
-- =============================================================================

CREATE TABLE IF NOT EXISTS dim_producto (
    id_producto INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    id_publicacion BIGINT UNSIGNED NOT NULL UNIQUE,
    titulo_publicacion VARCHAR(500) NOT NULL,
    categoria_contenido VARCHAR(100) NOT NULL DEFAULT 'General',
    tipo_contenido ENUM('texto', 'multimedia', 'hibrido') NOT NULL DEFAULT 'texto',
    longitud_contenido INT NOT NULL,
    visibilidad VARCHAR(20) NOT NULL,
    fecha_carga_dw DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_categoria (categoria_contenido),
    INDEX idx_tipo (tipo_contenido),
    INDEX idx_id_publicacion (id_publicacion)
) ENGINE=InnoDB COMMENT='Dimensión de publicaciones/contenido';

-- =============================================================================
-- 5.2.3 DIMENSIÓN: CLIENTE (Usuario)
-- Jerarquía: Región > País > Segmento
-- =============================================================================

CREATE TABLE IF NOT EXISTS dim_cliente (
    id_cliente INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    id_usuario BIGINT UNSIGNED NOT NULL UNIQUE,
    nombre_completo VARCHAR(200) NOT NULL,
    email VARCHAR(255) NOT NULL,
    pais VARCHAR(100) NOT NULL,
    region VARCHAR(100) NOT NULL,
    segmento_cliente VARCHAR(50) NOT NULL,
    dias_registrado INT NOT NULL,
    estado_actual VARCHAR(20) NOT NULL,
    es_activo TINYINT(1) NOT NULL DEFAULT 1,
    fecha_carga_dw DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_pais (pais),
    INDEX idx_region (region),
    INDEX idx_segmento (segmento_cliente),
    INDEX idx_id_usuario (id_usuario)
) ENGINE=InnoDB COMMENT='Dimensión de usuarios/clientes con segmentación';

-- =============================================================================
-- 5.2.4 DIMENSIÓN: VENDEDOR (Creador de Contenido)
-- Jerarquía: Sucursal > Región > ID
-- =============================================================================

CREATE TABLE IF NOT EXISTS dim_vendedor (
    id_vendedor INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    id_usuario_creador BIGINT UNSIGNED NOT NULL UNIQUE,
    nombre_vendedor VARCHAR(200) NOT NULL,
    email_vendedor VARCHAR(255) NOT NULL,
    region_principal VARCHAR(100) NOT NULL,
    sucursal VARCHAR(100) NOT NULL,
    nivel_influencia VARCHAR(50) NOT NULL DEFAULT 'Regular',
    total_followers INT NOT NULL DEFAULT 0,
    porcentaje_contenido_publico DECIMAL(5,2) NOT NULL,
    fecha_carga_dw DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_region (region_principal),
    INDEX idx_sucursal (sucursal),
    INDEX idx_influencia (nivel_influencia),
    INDEX idx_id_usuario (id_usuario_creador)
) ENGINE=InnoDB COMMENT='Dimensión de creadores/vendedores de contenido';

-- =============================================================================
-- 5.2.5 TABLA DE HECHOS: HECHOS_ACTIVIDAD_SOCIAL
-- =============================================================================

CREATE TABLE IF NOT EXISTS hechos_actividad_social (
    id_hecho BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    id_tiempo INT UNSIGNED NOT NULL,
    id_producto INT UNSIGNED NOT NULL,
    id_cliente INT UNSIGNED NOT NULL,
    id_vendedor INT UNSIGNED NOT NULL,

    cantidad_reacciones INT NOT NULL DEFAULT 0,
    cantidad_comentarios INT NOT NULL DEFAULT 0,
    cantidad_compartidas INT NOT NULL DEFAULT 0,
    engagement_score DECIMAL(10,4) NOT NULL DEFAULT 0,
    alcance_estimado INT NOT NULL DEFAULT 0,

    cantidad_likes INT NOT NULL DEFAULT 0,
    cantidad_loves INT NOT NULL DEFAULT 0,
    cantidad_wow INT NOT NULL DEFAULT 0,
    cantidad_triste INT NOT NULL DEFAULT 0,
    cantidad_enojo INT NOT NULL DEFAULT 0,

    fecha_carga_dw DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_ultima_actualizacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_hechos_tiempo FOREIGN KEY (id_tiempo)
        REFERENCES dim_tiempo(id_tiempo),
    CONSTRAINT fk_hechos_producto FOREIGN KEY (id_producto)
        REFERENCES dim_producto(id_producto),
    CONSTRAINT fk_hechos_cliente FOREIGN KEY (id_cliente)
        REFERENCES dim_cliente(id_cliente),
    CONSTRAINT fk_hechos_vendedor FOREIGN KEY (id_vendedor)
        REFERENCES dim_vendedor(id_vendedor),

    INDEX idx_tiempo (id_tiempo),
    INDEX idx_producto (id_producto),
    INDEX idx_cliente (id_cliente),
    INDEX idx_vendedor (id_vendedor),
    INDEX idx_fecha_carga (fecha_carga_dw),
    UNIQUE INDEX uq_hecho_unico (id_tiempo, id_producto, id_cliente, id_vendedor)
) ENGINE=InnoDB COMMENT='Tabla de hechos: actividad social publicación/día';

-- =============================================================================
-- 5.2.6 TABLA DE CONTROL: REGISTRO DE EJECUCIÓN ETL
-- =============================================================================

CREATE TABLE IF NOT EXISTS etl_ejecucion_log (
    id_ejecucion BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    nombre_proceso VARCHAR(100) NOT NULL,
    tipo_operacion ENUM('Extract', 'Transform', 'Load') NOT NULL,
    fecha_inicio DATETIME NOT NULL,
    fecha_fin DATETIME NULL,
    cantidad_registros_procesados INT NOT NULL DEFAULT 0,
    cantidad_registros_insertados INT NOT NULL DEFAULT 0,
    cantidad_errores INT NOT NULL DEFAULT 0,
    estado ENUM('iniciado', 'en_progreso', 'completado', 'error') NOT NULL DEFAULT 'iniciado',
    mensaje_error TEXT NULL,
    duracion_segundos INT NULL,
    INDEX idx_fecha_inicio (fecha_inicio),
    INDEX idx_estado (estado)
) ENGINE=InnoDB COMMENT='Log de auditoría para procesos ETL';

-- =============================================================================
-- 5.2.7 TABLA AGREGADA: AGREGADO_VENDEDOR_MENSUAL
-- =============================================================================

CREATE TABLE IF NOT EXISTS agregado_vendedor_mensual (
    id_agregado BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    id_vendedor INT UNSIGNED NOT NULL,
    anio INT NOT NULL,
    mes INT NOT NULL,

    total_publicaciones INT NOT NULL DEFAULT 0,
    total_reacciones BIGINT NOT NULL DEFAULT 0,
    total_comentarios BIGINT NOT NULL DEFAULT 0,
    total_alcance BIGINT NOT NULL DEFAULT 0,
    engagement_promedio DECIMAL(10,4) NOT NULL DEFAULT 0,

    fecha_calculo DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_agregado_vendedor FOREIGN KEY (id_vendedor)
        REFERENCES dim_vendedor(id_vendedor),
    UNIQUE INDEX uq_agregado (id_vendedor, anio, mes),
    INDEX idx_periodo (anio, mes)
) ENGINE=InnoDB COMMENT='Agregación mensual de métricas por vendedor';

-- =============================================================================
-- 5.2.8 TABLA AGREGADA: AGREGADO_CLIENTE_MENSUAL
-- =============================================================================

CREATE TABLE IF NOT EXISTS agregado_cliente_mensual (
    id_agregado BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    id_cliente INT UNSIGNED NOT NULL,
    anio INT NOT NULL,
    mes INT NOT NULL,

    total_interacciones INT NOT NULL DEFAULT 0,
    total_comentarios_realizados INT NOT NULL DEFAULT 0,
    total_reacciones_realizadas INT NOT NULL DEFAULT 0,

    fecha_calculo DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_agregado_cliente FOREIGN KEY (id_cliente)
        REFERENCES dim_cliente(id_cliente),
    UNIQUE INDEX uq_agregado_cliente (id_cliente, anio, mes),
    INDEX idx_periodo_cliente (anio, mes)
) ENGINE=InnoDB COMMENT='Agregación mensual de métricas por cliente';

-- Índices adicionales para drill-down

CREATE INDEX idx_hechos_drill_vendedor_producto
ON hechos_actividad_social(id_vendedor, id_producto, id_tiempo);

CREATE INDEX idx_hechos_drill_cliente_tiempo
ON hechos_actividad_social(id_cliente, id_tiempo, id_producto);

CREATE INDEX idx_hechos_metrics
ON hechos_actividad_social(engagement_score, alcance_estimado, cantidad_reacciones);

-- Verificación rápida

SELECT 'Data Warehouse Schema - Verificación' AS Status;

SELECT
    TABLE_NAME,
    TABLE_ROWS,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS Size_MB
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'red_social_db'
  AND (TABLE_NAME LIKE 'dim_%'
       OR TABLE_NAME LIKE 'hechos_%'
       OR TABLE_NAME LIKE 'agregado_%'
       OR TABLE_NAME LIKE 'etl_%')
ORDER BY TABLE_NAME;
